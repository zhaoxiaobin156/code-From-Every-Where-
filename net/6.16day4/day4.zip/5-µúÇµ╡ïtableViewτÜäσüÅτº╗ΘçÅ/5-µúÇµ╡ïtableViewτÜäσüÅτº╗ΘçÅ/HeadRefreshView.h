//
//  HeadRefreshView.h
//  5-检测tableView的偏移量
//
//  Created by mac on 16/6/16.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeadRefreshView : UIView

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *act;

@property (weak, nonatomic) IBOutlet UILabel *label;

@end
