//
//  MovieModel.m
//  6-下拉刷新第三方库
//
//  Created by mac on 16/6/16.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import "MovieModel.h"

@implementation MovieModel

+(JSONKeyMapper *)keyMapper{

    return [[JSONKeyMapper alloc] initWithDictionary:@{@"description":@"des"}];
}

@end
