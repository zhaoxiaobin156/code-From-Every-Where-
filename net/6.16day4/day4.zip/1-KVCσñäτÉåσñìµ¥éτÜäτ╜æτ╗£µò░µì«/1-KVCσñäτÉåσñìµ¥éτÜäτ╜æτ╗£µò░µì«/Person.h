//
//  Person.h
//  1-KVC处理复杂的网络数据
//
//  Created by mac on 16/6/16.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Dog : NSObject

@property(nonatomic,copy)NSString *color;

@end

@interface Person : NSObject

@end
