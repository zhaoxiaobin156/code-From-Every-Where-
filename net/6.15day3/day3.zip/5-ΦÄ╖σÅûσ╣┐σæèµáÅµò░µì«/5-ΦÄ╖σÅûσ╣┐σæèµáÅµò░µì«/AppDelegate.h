//
//  AppDelegate.h
//  5-获取广告栏数据
//
//  Created by lgh on 16/6/15.
//  Copyright (c) 2016年 lgh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

