//
//  GGCollectionViewCell.m
//  
//
//  Created by lgh on 16/6/15.
//
//

#import "GGCollectionViewCell.h"

@implementation GGCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
