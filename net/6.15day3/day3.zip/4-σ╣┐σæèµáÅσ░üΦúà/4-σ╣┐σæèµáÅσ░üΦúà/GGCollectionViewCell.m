//
//  GGCollectionViewCell.m
//  4-广告栏封装
//
//  Created by mac on 16/6/15.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import "GGCollectionViewCell.h"

@implementation GGCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
