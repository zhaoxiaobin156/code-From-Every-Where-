//
//  CatCell.m
//  2-瀑布流
//
//  Created by mac on 16/6/18.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import "CatCell.h"

@implementation CatCell

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}

@end
