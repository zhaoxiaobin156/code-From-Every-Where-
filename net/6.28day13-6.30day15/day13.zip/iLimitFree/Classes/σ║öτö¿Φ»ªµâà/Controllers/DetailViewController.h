//
//  DetailViewController.h
//  iLimitFree
//
//  Created by mac on 16/6/29.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

//接收上一个页面传递过来的applicationId
@property(nonatomic,assign)NSString *applicationId;

@end
