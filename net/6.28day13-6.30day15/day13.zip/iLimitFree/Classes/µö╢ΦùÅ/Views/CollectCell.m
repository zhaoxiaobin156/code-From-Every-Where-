//
//  CollectCell.m
//  iLimitFree
//
//  Created by mac on 16/6/30.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import "CollectCell.h"

@implementation CollectCell

@end
