//
//  CollectModel.m
//  iLimitFree
//
//  Created by mac on 16/6/30.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import "CollectModel.h"

@implementation CollectModel

@end
