//
//  CollectModel.h
//  iLimitFree
//
//  Created by mac on 16/6/30.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CollectModel : NSObject

@property(nonatomic,copy)NSString *applicationId;

@property(nonatomic,strong)UIImage *image;

@property(nonatomic,copy)NSString *name;

@end
