//
//  CollectViewController.h
//  iLimitFree
//
//  Created by mac on 16/6/30.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectViewController : UIViewController

@end
