//
//  ReduceViewController.h
//  iLimitFree
//
//  Created by mac on 16/6/29.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import "BaseViewController.h"

@interface ReduceViewController : BaseViewController

@end
