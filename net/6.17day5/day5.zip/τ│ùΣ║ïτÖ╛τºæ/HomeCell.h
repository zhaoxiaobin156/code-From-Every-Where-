//
//  HomeCell.h
//  
//
//  Created by lgh on 16/4/5.
//
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"

@interface HomeCell : UITableViewCell

- (void)refreshUI:(HomeModel *)model;

@end

