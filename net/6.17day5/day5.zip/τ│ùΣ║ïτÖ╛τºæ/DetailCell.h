//
//  DetailCell.h
//  
//
//  Created by lgh on 16/4/5.
//
//

#import <UIKit/UIKit.h>
#import "DetailModel.h"

@interface DetailCell : UITableViewCell

- (void)refreshUI:(DetailModel *)model;

@end
