//
//  TwoCell.h
//  
//
//  Created by lgh on 16/4/6.
//
//

#import <UIKit/UIKit.h>
#import "NewsModel.h"

@interface TwoCell : UITableViewCell

- (void)refreshUI:(NewsModel *)model;

@end
