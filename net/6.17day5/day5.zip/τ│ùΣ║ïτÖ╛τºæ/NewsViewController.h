//
//  NewsViewController.h
//  
//
//  Created by lgh on 16/4/6.
//
//

#import <UIKit/UIKit.h>

@interface NewsViewController : UIViewController

@end
