//
//  TableViewCell.m
//  2-综合多视图布局
//
//  Created by mac on 16/6/17.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
