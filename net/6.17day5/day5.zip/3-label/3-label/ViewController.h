//
//  ViewController.h
//  3-label
//
//  Created by mac on 16/6/17.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

