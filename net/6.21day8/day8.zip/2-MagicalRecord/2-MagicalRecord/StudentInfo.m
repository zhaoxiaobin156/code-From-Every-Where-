//
//  StudentInfo.m
//  
//
//  Created by mac on 16/6/21.
//
//

#import "StudentInfo.h"


@implementation StudentInfo

@dynamic name;
@dynamic age;

@end
