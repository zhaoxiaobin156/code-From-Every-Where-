//
//  Copyright (c) 2015 Magical Panda Software LLC. All rights reserved.

#import "MagicalRecord.h"

@interface MagicalRecord (ShorthandMethods)

+ (void)enableShorthandMethods;

@end
