//
//  RightViewController.h
//  1-UISplitViewController
//
//  Created by mac on 16/6/23.
//  Copyright (c) 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RightViewController : UIViewController

@property(nonatomic,copy)NSString *fontStr;

@end
