//
//  GGCollectionViewCell.h
//  
//
//  Created by lgh on 16/6/15.
//
//

#import <UIKit/UIKit.h>

@interface GGCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
