//
//  ViewController.m
//  7-cell里面嵌套视图
//
//  Created by lgh on 16/6/23.
//  Copyright (c) 2016年 lgh. All rights reserved.
//
//  xib + 代码
#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
