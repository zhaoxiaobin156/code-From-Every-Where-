//
//  CollectionViewCell.m
//  
//
//  Created by lgh on 16/6/23.
//
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}

@end
