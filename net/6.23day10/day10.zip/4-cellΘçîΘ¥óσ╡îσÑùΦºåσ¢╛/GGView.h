//
//  GGView.h
//  
//
//  Created by lgh on 16/6/15.
//
//

#import <UIKit/UIKit.h>

@interface GGView : UIView

@property (nonatomic, strong) NSArray *dataSource; //!< 数据源

@end
